print('\t-->program ke III<--')

kalimat = input ('masukkan kalimat: ')
print (kalimat.swapcase())
# swapcase()